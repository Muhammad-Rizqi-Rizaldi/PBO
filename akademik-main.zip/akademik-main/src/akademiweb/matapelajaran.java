/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package akademiweb;

public class matapelajaran {
    private int kodemapel;
    private String namamapel;

    public matapelajaran(int kodeMapel, String namaMapel) {
        this.kodemapel = kodeMapel;
        this.namamapel = namaMapel;
    }

    public int getKodeMapel() {
        return kodemapel;
    }

    public String getNamaMapel() {
        return namamapel;
    }
}



